"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // src/util/stableStringify.ts
  function stableStringify(obj, space = 2) {
    return JSON.stringify(sortValue(obj), null, space);
  }
  function sortValue(val) {
    if (Array.isArray(val)) return val.map(sortValue);
    if (val && typeof val === "object" && val.constructor === Object) {
      return Object.keys(val).sort().reduce(
        (acc, key) => {
          acc[key] = sortValue(val[key]);
          return acc;
        },
        {}
      );
    }
    return val;
  }

  // src/export/hash.ts
  function sha256Pure(str) {
    const bytes = stringToUtf8Bytes(str);
    const K = [
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ];
    let h0 = 1779033703, h1 = 3144134277, h2 = 1013904242, h3 = 2773480762;
    let h4 = 1359893119, h5 = 2600822924, h6 = 528734635, h7 = 1541459225;
    const msgLen = bytes.length;
    const bitLen = msgLen * 8;
    const paddedLen = Math.ceil((msgLen + 9) / 64) * 64;
    const padded = new Uint8Array(paddedLen);
    padded.set(bytes);
    padded[msgLen] = 128;
    for (let i = 0; i < 8; i++) {
      padded[paddedLen - 1 - i] = bitLen >>> i * 8 & 255;
    }
    for (let chunk = 0; chunk < paddedLen; chunk += 64) {
      const w = new Uint32Array(64);
      for (let i = 0; i < 16; i++) {
        w[i] = padded[chunk + i * 4] << 24 | padded[chunk + i * 4 + 1] << 16 | padded[chunk + i * 4 + 2] << 8 | padded[chunk + i * 4 + 3];
      }
      for (let i = 16; i < 64; i++) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (let i = 0; i < 64; i++) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = h + S1 + ch + K[i] + w[i] >>> 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = S0 + maj >>> 0;
        h = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
      h5 = h5 + f >>> 0;
      h6 = h6 + g >>> 0;
      h7 = h7 + h >>> 0;
    }
    const hash = [h0, h1, h2, h3, h4, h5, h6, h7];
    return hash.map((h) => h.toString(16).padStart(8, "0")).join("");
  }
  function rotr(n, x) {
    return n >>> x | n << 32 - x;
  }
  function stringToUtf8Bytes(str) {
    const bytes = [];
    for (let i = 0; i < str.length; i++) {
      let charCode = str.charCodeAt(i);
      if (charCode < 128) {
        bytes.push(charCode);
      } else if (charCode < 2048) {
        bytes.push(192 | charCode >> 6, 128 | charCode & 63);
      } else if (charCode < 55296 || charCode >= 57344) {
        bytes.push(
          224 | charCode >> 12,
          128 | charCode >> 6 & 63,
          128 | charCode & 63
        );
      } else {
        i++;
        charCode = 65536 + ((charCode & 1023) << 10 | str.charCodeAt(i) & 1023);
        bytes.push(
          240 | charCode >> 18,
          128 | charCode >> 12 & 63,
          128 | charCode >> 6 & 63,
          128 | charCode & 63
        );
      }
    }
    return new Uint8Array(bytes);
  }
  async function sha256(text) {
    return sha256Pure(text);
  }

  // src/export/buildVariablesJson.ts
  var PLUGIN_VERSION = "0.1.0";
  async function buildVariablesJson(figmaApi) {
    try {
      const collections = await figma.variables.getLocalVariableCollectionsAsync();
      const allVars = await figma.variables.getLocalVariablesAsync();
      const fileName = figmaApi.root.name;
      const fileId = figmaApi.root.id;
      const byCollection = {};
      for (const c of collections) {
        byCollection[c.id] = {
          id: c.id,
          name: c.name,
          modes: c.modes.map((m) => ({
            id: m.modeId,
            name: m.name
          })),
          variables: []
        };
      }
      for (const v of allVars) {
        const col = byCollection[v.variableCollectionId];
        if (!col) continue;
        const valuesByMode = {};
        for (const modeId of Object.keys(v.valuesByMode)) {
          const raw = v.valuesByMode[modeId];
          valuesByMode[modeId] = normalizeModeValue(raw);
        }
        const exported = {
          id: v.id,
          name: v.name,
          resolvedType: v.resolvedType,
          isAlias: Object.values(valuesByMode).some((m) => m.type === "ALIAS"),
          scopes: v.scopes || [],
          valuesByMode,
          codeSyntax: v.codeSyntax || void 0
        };
        col.variables.push(exported);
      }
      const sortedCollections = Object.values(byCollection).sort((a, b) => a.name.localeCompare(b.name)).map((c) => __spreadProps(__spreadValues({}, c), {
        variables: c.variables.sort((a, b) => a.name.localeCompare(b.name))
      }));
      const root = {
        meta: {
          exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
          fileName,
          pluginVersion: PLUGIN_VERSION,
          figmaFileId: fileId,
          collectionsCount: sortedCollections.length,
          variablesCount: sortedCollections.reduce((sum, c) => sum + c.variables.length, 0),
          contentHash: ""
          // Will be set below
        },
        collections: sortedCollections
      };
      const stableContent = {
        meta: {
          fileName,
          pluginVersion: PLUGIN_VERSION,
          figmaFileId: fileId,
          collectionsCount: root.meta.collectionsCount,
          variablesCount: root.meta.variablesCount
        },
        collections: sortedCollections
      };
      const json = stableStringify(stableContent, 2);
      root.meta.contentHash = await sha256(json);
      return root;
    } catch (error) {
      throw new Error(
        `Failed to build variables JSON: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  }
  function normalizeModeValue(raw) {
    var _a;
    if (!raw || typeof raw !== "object") {
      return inferPrimitive(raw);
    }
    if (raw.type === "VARIABLE_ALIAS" && raw.id) {
      return { type: "ALIAS", refVariableId: raw.id };
    }
    if (typeof raw.r === "number" && typeof raw.g === "number" && typeof raw.b === "number") {
      return { type: "COLOR", value: { r: raw.r, g: raw.g, b: raw.b, a: (_a = raw.a) != null ? _a : 1 } };
    }
    return inferPrimitive(raw);
  }
  function inferPrimitive(val) {
    switch (typeof val) {
      case "string":
        return { type: "STRING", value: val };
      case "number":
        return { type: "NUMBER", value: val };
      case "boolean":
        return { type: "BOOLEAN", value: val };
      default:
        return { type: "STRING", value: String(val) };
    }
  }

  // src/messaging.ts
  var SETTINGS_KEY = "figmaVarSync_settings_v1";
  function defaultSettings() {
    return {
      owner: "",
      repo: "",
      branch: "main",
      folder: "",
      filename: "variables.json",
      commitPrefix: "",
      dryRun: false
    };
  }

  // src/util/retry.ts
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function defaultShouldRetry(error, _attempt) {
    const errorMsg = error.message.toLowerCase();
    if (errorMsg.includes("network") || errorMsg.includes("fetch") || errorMsg.includes("timeout") || errorMsg.includes("econnrefused")) {
      return true;
    }
    if (errorMsg.includes("50") || errorMsg.includes("429") || errorMsg.includes("rate limit")) {
      return true;
    }
    if (errorMsg.includes("409") || errorMsg.includes("conflict")) {
      return true;
    }
    if (errorMsg.includes("401") || errorMsg.includes("403") || errorMsg.includes("404") || errorMsg.includes("422") || errorMsg.includes("unauthorized") || errorMsg.includes("forbidden") || errorMsg.includes("not found")) {
      return false;
    }
    return true;
  }
  async function withRetry(fn, options = {}) {
    const {
      maxAttempts = 3,
      initialDelay = 1e3,
      maxDelay = 1e4,
      backoffMultiplier = 2,
      shouldRetry = defaultShouldRetry,
      onRetry
    } = options;
    let lastError;
    let currentDelay = initialDelay;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        if (attempt >= maxAttempts) {
          throw lastError;
        }
        if (!shouldRetry(lastError, attempt)) {
          throw lastError;
        }
        if (onRetry) {
          onRetry(lastError, attempt, currentDelay);
        }
        await delay(currentDelay);
        currentDelay = Math.min(currentDelay * backoffMultiplier, maxDelay);
      }
    }
    throw lastError;
  }

  // src/github/githubClient.ts
  async function ghFetch(url, token, init = {}) {
    const headers = {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`
    };
    if (init.body && !(init.headers && init.headers["Content-Type"])) {
      headers["Content-Type"] = "application/json";
    }
    init.headers = __spreadValues(__spreadValues({}, headers), init.headers);
    return withRetry(
      async () => {
        return await fetch(url, init);
      },
      {
        maxAttempts: 3,
        initialDelay: 1e3
      }
    );
  }
  async function ensureBranch(owner, repo, branch, token) {
    const refUrl = `https://api.github.com/repos/${owner}/${repo}/git/ref/heads/${branch}`;
    const ref = await ghFetch(refUrl, token);
    if (ref.status === 200) return;
    if (ref.status !== 404) throw new Error(`Failed reading branch: ${ref.status}`);
    const repoRes = await ghFetch(`https://api.github.com/repos/${owner}/${repo}`, token);
    if (!repoRes.ok) throw new Error("Cannot read repository metadata");
    const repoJson = await repoRes.json();
    const defaultBranch = repoJson.default_branch;
    const baseRefRes = await ghFetch(
      `https://api.github.com/repos/${owner}/${repo}/git/ref/heads/${defaultBranch}`,
      token
    );
    if (!baseRefRes.ok) throw new Error("Cannot read default branch ref");
    const baseRef = await baseRefRes.json();
    const sha = baseRef.object.sha;
    const createRes = await ghFetch(`https://api.github.com/repos/${owner}/${repo}/git/refs`, token, {
      method: "POST",
      body: JSON.stringify({ ref: `refs/heads/${branch}`, sha })
    });
    if (!createRes.ok) throw new Error("Failed to create branch");
  }
  async function getExistingFile(owner, repo, branch, path, token) {
    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}?ref=${branch}`;
    const res = await ghFetch(url, token);
    if (res.status === 404) return null;
    if (!res.ok) throw new Error(`Failed reading existing file: ${res.status}`);
    return await res.json();
  }
  function toBase64(str) {
    const base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const utf8Bytes = [];
    for (let i = 0; i < str.length; i++) {
      let charCode = str.charCodeAt(i);
      if (charCode < 128) {
        utf8Bytes.push(charCode);
      } else if (charCode < 2048) {
        utf8Bytes.push(192 | charCode >> 6, 128 | charCode & 63);
      } else if (charCode < 55296 || charCode >= 57344) {
        utf8Bytes.push(
          224 | charCode >> 12,
          128 | charCode >> 6 & 63,
          128 | charCode & 63
        );
      } else {
        i++;
        charCode = 65536 + ((charCode & 1023) << 10 | str.charCodeAt(i) & 1023);
        utf8Bytes.push(
          240 | charCode >> 18,
          128 | charCode >> 12 & 63,
          128 | charCode >> 6 & 63,
          128 | charCode & 63
        );
      }
    }
    let result = "";
    for (let i = 0; i < utf8Bytes.length; i += 3) {
      const byte1 = utf8Bytes[i];
      const byte2 = i + 1 < utf8Bytes.length ? utf8Bytes[i + 1] : 0;
      const byte3 = i + 2 < utf8Bytes.length ? utf8Bytes[i + 2] : 0;
      const enc1 = byte1 >> 2;
      const enc2 = (byte1 & 3) << 4 | byte2 >> 4;
      const enc3 = (byte2 & 15) << 2 | byte3 >> 6;
      const enc4 = byte3 & 63;
      result += base64Chars[enc1] + base64Chars[enc2];
      result += i + 1 < utf8Bytes.length ? base64Chars[enc3] : "=";
      result += i + 2 < utf8Bytes.length ? base64Chars[enc4] : "=";
    }
    return result;
  }
  function fromBase64(str) {
    const base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const base64Lookup = {};
    for (let i2 = 0; i2 < base64Chars.length; i2++) {
      base64Lookup[base64Chars[i2]] = i2;
    }
    const cleanStr = str.replace(/[\s=]/g, "");
    const bytes = [];
    for (let i2 = 0; i2 < cleanStr.length; i2 += 4) {
      const enc1 = base64Lookup[cleanStr[i2]] || 0;
      const enc2 = base64Lookup[cleanStr[i2 + 1]] || 0;
      const enc3 = base64Lookup[cleanStr[i2 + 2]] || 0;
      const enc4 = base64Lookup[cleanStr[i2 + 3]] || 0;
      bytes.push(enc1 << 2 | enc2 >> 4);
      if (i2 + 2 < cleanStr.length) {
        bytes.push((enc2 & 15) << 4 | enc3 >> 2);
      }
      if (i2 + 3 < cleanStr.length) {
        bytes.push((enc3 & 3) << 6 | enc4);
      }
    }
    let result = "";
    let i = 0;
    while (i < bytes.length) {
      const byte1 = bytes[i++];
      if (byte1 < 128) {
        result += String.fromCharCode(byte1);
      } else if (byte1 < 224) {
        const byte2 = bytes[i++];
        result += String.fromCharCode((byte1 & 31) << 6 | byte2 & 63);
      } else if (byte1 < 240) {
        const byte2 = bytes[i++];
        const byte3 = bytes[i++];
        result += String.fromCharCode(
          (byte1 & 15) << 12 | (byte2 & 63) << 6 | byte3 & 63
        );
      } else {
        const byte2 = bytes[i++];
        const byte3 = bytes[i++];
        const byte4 = bytes[i++];
        let codePoint = (byte1 & 7) << 18 | (byte2 & 63) << 12 | (byte3 & 63) << 6 | byte4 & 63;
        codePoint -= 65536;
        result += String.fromCharCode(55296 + (codePoint >> 10), 56320 + (codePoint & 1023));
      }
    }
    return result;
  }
  async function upsertFile(options) {
    var _a;
    const { owner, repo, branch, path, content, token, commitMessage, currentHash } = options;
    await ensureBranch(owner, repo, branch, token);
    const existing = await getExistingFile(owner, repo, branch, path, token);
    if (existing) {
      try {
        const decoded = fromBase64(existing.content);
        let embeddedHash;
        try {
          const parsed = JSON.parse(decoded);
          embeddedHash = (_a = parsed == null ? void 0 : parsed.meta) == null ? void 0 : _a.contentHash;
        } catch (e) {
        }
        if (embeddedHash && embeddedHash === currentHash) {
          return { updated: false, skipped: true, url: existing.html_url };
        }
      } catch (e) {
      }
    }
    const body = {
      message: commitMessage,
      content: toBase64(content),
      branch,
      sha: existing ? existing.sha : void 0
      // SHA required for updates
    };
    async function attemptWrite(prevExisting, attempt) {
      var _a2, _b, _c;
      const putRes = await ghFetch(
        `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`,
        token,
        {
          method: "PUT",
          body: JSON.stringify(__spreadProps(__spreadValues({}, body), { sha: prevExisting ? prevExisting.sha : body.sha }))
        }
      );
      if (putRes.status === 409 && attempt === 0) {
        const latest = await getExistingFile(owner, repo, branch, path, token);
        if (latest) {
          try {
            const decoded = fromBase64(latest.content);
            const parsed = JSON.parse(decoded);
            const embedded = (_a2 = parsed == null ? void 0 : parsed.meta) == null ? void 0 : _a2.contentHash;
            if (embedded && embedded === currentHash) {
              return { updated: false, skipped: true, url: latest.html_url };
            }
          } catch (e) {
          }
        }
        return attemptWrite(latest, 1);
      }
      if (!putRes.ok) {
        throw new Error(`Failed to write file: ${putRes.status}`);
      }
      const result = await putRes.json();
      return {
        updated: true,
        skipped: false,
        url: (_b = result.content) == null ? void 0 : _b.html_url,
        commitSha: (_c = result.commit) == null ? void 0 : _c.sha
      };
    }
    return attemptWrite(existing, 0);
  }

  // src/util/validation.ts
  function validateGitHubOwner(owner) {
    if (!owner || !owner.trim()) {
      return { valid: false, error: "Owner is required" };
    }
    if (!/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(owner.trim())) {
      return { valid: false, error: "Invalid owner format (alphanumeric and hyphens only)" };
    }
    if (owner.trim().length > 39) {
      return { valid: false, error: "Owner name too long (max 39 characters)" };
    }
    return { valid: true };
  }
  function validateGitHubRepo(repo) {
    if (!repo || !repo.trim()) {
      return { valid: false, error: "Repository name is required" };
    }
    if (!/^[a-zA-Z0-9._-]+$/.test(repo.trim())) {
      return {
        valid: false,
        error: "Invalid repository format (alphanumeric, hyphens, underscores, dots only)"
      };
    }
    if (repo.trim().length > 100) {
      return { valid: false, error: "Repository name too long (max 100 characters)" };
    }
    return { valid: true };
  }
  function validateBranchName(branch) {
    if (!branch || !branch.trim()) {
      return { valid: false, error: "Branch name is required" };
    }
    if (branch.trim().startsWith("-") || branch.trim().endsWith(".lock") || /\.\./.test(branch)) {
      return { valid: false, error: "Invalid branch name format" };
    }
    if (branch.trim().length > 255) {
      return { valid: false, error: "Branch name too long (max 255 characters)" };
    }
    return { valid: true };
  }
  function validateFilename(filename) {
    if (!filename || !filename.trim()) {
      return { valid: false, error: "Filename is required" };
    }
    if (filename.includes("..") || filename.includes("//")) {
      return { valid: false, error: "Invalid filename (no path traversal)" };
    }
    if (!/^[a-zA-Z0-9._-]+\.json$/i.test(filename.trim())) {
      return {
        valid: false,
        error: "Filename must end with .json and contain only alphanumeric, hyphens, underscores, dots"
      };
    }
    return { valid: true };
  }
  function validateFolderPath(folder) {
    if (!folder || !folder.trim()) {
      return { valid: true };
    }
    if (folder.includes("..")) {
      return { valid: false, error: "Invalid folder path (no path traversal)" };
    }
    const normalized = folder.trim().replace(/^\/+/, "").replace(/\/+$/, "");
    if (normalized && !/^[a-zA-Z0-9._/-]+$/.test(normalized)) {
      return {
        valid: false,
        error: "Invalid folder path (alphanumeric, hyphens, underscores, dots, slashes only)"
      };
    }
    return { valid: true };
  }
  function validateAllSettings(settings) {
    const ownerResult = validateGitHubOwner(settings.owner);
    if (!ownerResult.valid) return ownerResult;
    const repoResult = validateGitHubRepo(settings.repo);
    if (!repoResult.valid) return repoResult;
    const branchResult = validateBranchName(settings.branch);
    if (!branchResult.valid) return branchResult;
    const filenameResult = validateFilename(settings.filename);
    if (!filenameResult.valid) return filenameResult;
    if (settings.folder) {
      const folderResult = validateFolderPath(settings.folder);
      if (!folderResult.valid) return folderResult;
    }
    return { valid: true };
  }

  // src/plugin.ts
  figma.showUI(__html__, { width: 520, height: 620, themeColors: true });
  async function getStoredSettings() {
    try {
      const raw = figma.root.getPluginData(SETTINGS_KEY);
      if (!raw) return defaultSettings();
      return __spreadValues(__spreadValues({}, defaultSettings()), JSON.parse(raw));
    } catch (e) {
      return defaultSettings();
    }
  }
  async function saveSettings(settings) {
    figma.root.setPluginData(SETTINGS_KEY, JSON.stringify(settings));
  }
  async function hasToken() {
    return await figma.clientStorage.getAsync("github_pat") ? true : false;
  }
  async function validateTokenAndNotify() {
    try {
      const token = await figma.clientStorage.getAsync("github_pat");
      if (!token) {
        figma.ui.postMessage({ type: "TOKEN_VALIDATION", ok: false, error: "No token stored" });
        return;
      }
      const res = await fetch("https://api.github.com/user", {
        headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" }
      });
      if (!res.ok) {
        figma.ui.postMessage({ type: "TOKEN_VALIDATION", ok: false, error: `Status ${res.status}` });
        return;
      }
      const json = await res.json();
      figma.ui.postMessage({ type: "TOKEN_VALIDATION", ok: true, login: json.login });
    } catch (e) {
      const error = e instanceof Error ? e.message : "Validation failed";
      figma.ui.postMessage({ type: "TOKEN_VALIDATION", ok: false, error });
    }
  }
  figma.ui.onmessage = async (msg) => {
    if (msg.type === "REQUEST_EXPORT") {
      try {
        const data = await buildVariablesJson(figma);
        figma.ui.postMessage({ type: "EXPORT_RESULT", ok: true, data });
      } catch (e) {
        figma.ui.postMessage({
          type: "EXPORT_RESULT",
          ok: false,
          error: e.message
        });
      }
    }
    if (msg.type === "FETCH_REMOTE_EXPORT") {
      try {
        const settings = await getStoredSettings();
        const token = await figma.clientStorage.getAsync("github_pat");
        if (!token) {
          figma.ui.postMessage({
            type: "FETCH_REMOTE_EXPORT_RESULT",
            ok: false,
            error: "Missing token"
          });
          return;
        }
        const path = (settings.folder ? settings.folder.replace(/\\+/g, "/").replace(/^\//, "").replace(/\/$/, "") + "/" : "") + settings.filename;
        const url = `https://api.github.com/repos/${settings.owner}/${settings.repo}/contents/${encodeURIComponent(path)}?ref=${settings.branch}`;
        const res = await fetch(url, {
          headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${token}` }
        });
        if (res.status === 404) {
          figma.ui.postMessage({ type: "FETCH_REMOTE_EXPORT_RESULT", ok: true, data: null });
          return;
        }
        if (!res.ok) {
          figma.ui.postMessage({
            type: "FETCH_REMOTE_EXPORT_RESULT",
            ok: false,
            error: `Status ${res.status}`
          });
          return;
        }
        const json = await res.json();
        try {
          const decoded = fromBase64(json.content);
          const parsed = JSON.parse(decoded);
          figma.ui.postMessage({ type: "FETCH_REMOTE_EXPORT_RESULT", ok: true, data: parsed });
        } catch (e) {
          const error = e instanceof Error ? e.message : "Unknown";
          figma.ui.postMessage({
            type: "FETCH_REMOTE_EXPORT_RESULT",
            ok: false,
            error: "Parse error: " + error
          });
        }
      } catch (e) {
        const error = e instanceof Error ? e.message : "Unknown error";
        figma.ui.postMessage({ type: "FETCH_REMOTE_EXPORT_RESULT", ok: false, error });
      }
    }
    if (msg.type === "REQUEST_SETTINGS") {
      const s = await getStoredSettings();
      figma.ui.postMessage({
        type: "SETTINGS_RESPONSE",
        payload: __spreadProps(__spreadValues({}, s), { tokenPresent: await hasToken() })
      });
    }
    if (msg.type === "SAVE_SETTINGS") {
      await saveSettings(msg.payload);
      figma.ui.postMessage({
        type: "NOTIFY",
        level: "info",
        message: "Settings saved"
      });
    }
    if (msg.type === "SAVE_TOKEN") {
      try {
        await figma.clientStorage.setAsync("github_pat", msg.token.trim());
        figma.ui.postMessage({ type: "NOTIFY", level: "info", message: "Token stored locally" });
        figma.ui.postMessage({
          type: "SETTINGS_RESPONSE",
          payload: __spreadProps(__spreadValues({}, await getStoredSettings()), { tokenPresent: true })
        });
        await validateTokenAndNotify();
      } catch (e) {
        figma.ui.postMessage({ type: "NOTIFY", level: "error", message: "Failed saving token" });
      }
    }
    if (msg.type === "CLEAR_TOKEN") {
      await figma.clientStorage.deleteAsync("github_pat");
      figma.ui.postMessage({ type: "NOTIFY", level: "info", message: "Token cleared" });
      figma.ui.postMessage({
        type: "SETTINGS_RESPONSE",
        payload: __spreadProps(__spreadValues({}, await getStoredSettings()), { tokenPresent: false })
      });
    }
    if (msg.type === "VALIDATE_TOKEN") {
      await validateTokenAndNotify();
    }
    if (msg.type === "COMMIT_REQUEST") {
      try {
        const exportData = msg.exportData;
        if (msg.dryRun) {
          figma.ui.postMessage({ type: "COMMIT_RESULT", ok: true, skipped: true });
          return;
        }
        const token = await figma.clientStorage.getAsync("github_pat");
        if (!token) {
          figma.ui.postMessage({ type: "COMMIT_RESULT", ok: false, error: "Missing token" });
          return;
        }
        const settings = await getStoredSettings();
        const validationResult = validateAllSettings({
          owner: settings.owner,
          repo: settings.repo,
          branch: settings.branch,
          filename: settings.filename,
          folder: settings.folder
        });
        if (!validationResult.valid) {
          figma.ui.postMessage({
            type: "COMMIT_RESULT",
            ok: false,
            error: `Validation error: ${validationResult.error}`
          });
          return;
        }
        const newHash = exportData.meta.contentHash || "";
        if (settings.lastHash && settings.lastHash === newHash) {
          figma.ui.postMessage({ type: "COMMIT_RESULT", ok: true, skipped: true });
          return;
        }
        const vars = exportData.meta.variablesCount;
        const cols = exportData.meta.collectionsCount;
        const ts = (/* @__PURE__ */ new Date()).toISOString();
        const prefix = msg.commitPrefix || settings.commitPrefix ? `${msg.commitPrefix || settings.commitPrefix} ` : "";
        const commitMessage = `${prefix}chore(design): update Figma variables (${vars} vars, ${cols} collections) - ${ts}`;
        const path = (settings.folder ? settings.folder.replace(/\\+/g, "/").replace(/^\//, "").replace(/\/$/, "") + "/" : "") + settings.filename;
        const json = stableStringify(exportData, 2);
        const result = await upsertFile({
          owner: settings.owner,
          repo: settings.repo,
          branch: settings.branch,
          path,
          content: json,
          token,
          commitMessage,
          currentHash: newHash
        });
        if (!result.skipped && newHash) {
          await saveSettings(__spreadProps(__spreadValues({}, settings), { lastHash: newHash }));
        }
        figma.ui.postMessage({
          type: "COMMIT_RESULT",
          ok: true,
          skipped: result.skipped,
          url: result.url
        });
      } catch (e) {
        const error = e instanceof Error ? e : new Error(String(e));
        console.error("Commit error:", error);
        let msgText = error.message || "Unknown error";
        if (error.stack) {
          console.error("Stack:", error.stack);
        }
        if (/401/.test(msgText)) msgText = "Unauthorized (check token)";
        else if (/403/.test(msgText)) msgText = "Forbidden (check permissions)";
        else if (/404/.test(msgText)) msgText = "Not found (check repository)";
        else if (/422/.test(msgText)) msgText = "Validation failed (check branch/file path)";
        figma.ui.postMessage({ type: "COMMIT_RESULT", ok: false, error: msgText });
      }
    }
  };
  figma.on("run", () => {
    figma.ui.show();
    figma.ui.resize(520, 620);
    figma.ui.postMessage({ type: "REQUEST_SETTINGS" });
  });
})();
